
public class methods {
	int multiply(int num1,int num2) {
		int z=num1*num2;
		return z;
		
	}
	public static void main(String[] args) {
		methods obj=new methods();
		int x=obj.multiply(10, 20);
		System.out.println("multiplication: "+x);
		
		
		
	}
	

}
