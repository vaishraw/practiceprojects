package access_modifiers;

public class default_class {
	void display() {
		System.out.println("inside default class");
	}

}
