package access_modifiers;

public class public_class {
	public void display()
	{
		System.out.println("this is public access specifier");
	}

}
