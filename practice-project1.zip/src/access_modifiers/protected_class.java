package access_modifiers;

public class protected_class {
	protected void display() {
		System.out.println("inside a protected access specifier");
	}

}
