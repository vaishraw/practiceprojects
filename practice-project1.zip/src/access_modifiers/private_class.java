package access_modifiers;

public class private_class {
	private void display() {
		System.out.println("inside private specifier");
	}

}
