
public class Array {
	public static void main(String[] args) {
		int a[]= {11,22,33,44,55,66};
		for(int i=0;i<=5;i++) {
			System.out.println("element at "+i+": "+a[i]);
		}
		int b[][]= {{10,20,30,40,50},{60,70,80}};
		System.out.println("length of row 2: "+b[1].length);
				    
		}
		
	}


