import org.hibernate.Session;

import com.samples.domain.Message;
import com.samples.utils.HibernateUtils;

public class HibernateTest {

	public static void main(String[] args) {
		
		Session session = HibernateUtils.getSessionFactory().openSession();
		
		session.beginTransaction();
		
		Message message = new Message("Hello world with Hibernate with annotation"); 
		Message message1 = new Message("message1");
		Message message2 = new Message("message2");
		Message message3 = new Message("message3");
		Message message4 = new Message("message4");
		
		session.save(message);
		session.save(message1);
		session.save(message2);
		session.save(message3);
		session.save(message4);
		
		session.getTransaction().commit();
		
		session.close();
		
	}
}