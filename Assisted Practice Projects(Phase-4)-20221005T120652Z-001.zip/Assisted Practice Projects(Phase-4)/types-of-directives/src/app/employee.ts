// model class 
// export class Employee {
//     constructor(public id:number,
//         public name:string,
//         public salary:number){}
// }

// model interface 
export interface Employee{
    id:number;
    name:string;
    salary:number;
}

